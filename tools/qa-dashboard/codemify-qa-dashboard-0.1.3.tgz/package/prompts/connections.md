## Task: assess optional connections

Inspect the discovered CI and documentation configuration. For each desired connection, report its purpose, available evidence, exact permissions needed, and whether this package currently implements it.

This release supports local Git/work notes and importing downloaded native Playwright JSON reports:
qa-dashboard import <report.json> --environment <configured-id> --source ci --label "<meaningful name>"

It does not implement live GitHub/GitLab/Jira/Slack connectors or pipeline dispatch. Do not claim those are connected. Offer report import as the available path, and record a future connector requirement if requested.

For database or application credentials, identify variable NAMES and the owner's normal local secret mechanism. Do not ask for values in chat, edit .env, or put credentials into configuration. Production targets need explicit policy, not a guessed tag.

Write .qa-dashboard/connections-review.md with connected / configured / available through import / unavailable states. Optional connections must remain optional.
