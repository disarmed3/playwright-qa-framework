## Task: inventory this framework

1. Inspect package manifests, Playwright configuration(s), framework instructions, source structure, and setup/teardown references. If there are multiple configs or workspace packages, ask which one should be the dashboard root.
2. Run qa-dashboard scan --root <framework> for a static inventory. Inspect the relevant source references to establish what each layer and tag means.
3. When loading the trusted configuration is appropriate, run qa-dashboard discover --root <framework>. It writes the structured evidence at .qa-dashboard/discovery.json without running test bodies.
4. Identify projects/browsers, dependency projects, test groups, environment selection mechanisms, required variable NAMES, optional journals/catalogs, CI workflows, result formats, and existing AI workflows. Do not treat a filename or tag as proof of capability.
5. Write .qa-dashboard/framework-map.md with counts, source references, uncertainty, optional connections, unsupported features, and the smallest useful set of questions.
6. End with the next task: tailor. If the CLI reports unsupported behavior, document it instead of bypassing it.

Do not execute a full suite or change the active configuration in this step.
