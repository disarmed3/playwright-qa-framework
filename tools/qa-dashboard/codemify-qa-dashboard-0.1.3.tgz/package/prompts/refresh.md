## Task: rediscover without losing customizations

Read the current configuration and prior discovery evidence before refreshing. Run qa-dashboard discover to obtain current facts.

Identify added/removed/renamed tests, project changes, new tags, changed environments, CI changes, missing source paths, and orphaned labels or saved selections. Do not silently match renamed tests by similar title or relabel old evidence as current.

Preserve human names, descriptions, policy choices, and valid custom suite rules. Propose only the needed configuration differences in .qa-dashboard/proposal.json, with sources and unresolved questions in adaptation-review.md. Historical run snapshots remain immutable.

New production files are not automatically approved. New connections remain disconnected. Finish by following the validate workflow after the proposal is accepted.
