## Task: tailor the dashboard

Use current discovery evidence and confirmed answers to propose qa-dashboard.config.json.

- Preserve schemaVersion 1, the Playwright config path, and explicitly chosen default environment.
- Give products, features, and suites friendly names based on code and documentation.
- Use classifications with pathPrefix and product/layer/feature; the last matching rule wins.
- Use declarative suite filters (tags/files/products/layers/projects). These are live rules; saved UI suites are fixed selections.
- Add specific labels under "framework/relative/test.spec.ts::Exact original test title" (the source path, not the Playwright project name). Retain native test identities.
- Add journal directories/files and Markdown case catalogs only when they exist. Leave absent sources empty.
- Declare required variable NAMES as prerequisites, never credentials. Environment "env" contains only reviewed non-secret overrides. If urlEnv is set, env[urlEnv] must equal the displayed url.
- Enable a non-production environment only after its target and execution scope are established by the user. Keep production disabled unless reviewed file and tag allowlists exist.
- Check that all projects, browser variants, and setup dependencies remain represented.
- Preserve existing user overrides and write a proposal plus a review describing before/after changes and evidence.

Ask concise questions for ambiguous names, environment policy, and incomplete information. Do not change files under node_modules or copy the dashboard source into the framework.
