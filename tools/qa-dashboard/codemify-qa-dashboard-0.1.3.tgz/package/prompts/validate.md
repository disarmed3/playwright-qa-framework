## Task: verify the proposed adaptation

1. Compare the proposal with the current configuration and the evidence. Review changes with the user; apply only when authorized, using qa-dashboard apply <proposal.json> --yes.
2. Run qa-dashboard validate. Verify discovery counts, friendly classifications, environment availability, missing prerequisites, and optional source behavior.
3. Confirm that suite unions deduplicate exact test identities; test names alone are not identity. Verify project dependency/teardown requirements in run previews.
4. On Windows, inspect and verify tools/qa-dashboard/start.cmd after first-time setup. Preserve an existing launcher. Confirm it uses the installed local CLI and resolves this framework two folders above itself, including when opened from File Explorer or another working directory and when the path contains spaces. The generic template preserves inherited variables. Only for a reviewed Codemify course framework, verify its local QA_DASHBOARD_CODEMIFY_COURSE setting is 1 so BASE_URL and LOCAL_SANDBOX_DIR are absent from the dashboard process while other prerequisites remain available. Verify the printed URL, optional --port 4180, visible prerequisite/startup errors, and Ctrl+C shutdown. On other systems use the installed qa-dashboard start with the framework root and reviewed environment. Inspect overview, filters, suites, setup, and work/CI source states. Ensure no Codemify-specific claims survive unless this is a Codemify framework.
5. Only if authorized, select a small appropriate check on an approved environment and execute it. Do not run a whole suite or production simply to validate onboarding.
6. Verify actual results, persistence, and reports. Record what passed and what was not exercised in .qa-dashboard/validation.md.

Record launcher checks separately from test-run results. Confirm the framework README tells the student to double-click tools/qa-dashboard/start.cmd to reopen after setup, keep its terminal open, use --port 4180 if needed, and press Ctrl+C to stop. Package installation and init do not automatically copy or refresh this framework launcher. Do not claim a platform or launch path was verified unless it was actually exercised.

A green import or prior run does not prove the current checkout passes. Clearly record framework version, dashboard version, environment, and the limited verification scope.
