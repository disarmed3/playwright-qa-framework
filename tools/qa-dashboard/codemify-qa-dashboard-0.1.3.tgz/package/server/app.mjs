import Fastify from "fastify";
import staticFiles from "@fastify/static";
import { randomUUID } from "node:crypto";
import fs from "node:fs";
import path from "node:path";
import { DASHBOARD, VERSION, httpError, redact } from "./config.mjs";
import { Catalog, executionPlan } from "./catalog.mjs";
import { Store } from "./store.mjs";
import { Runner, ACTIVE, validateSelection } from "./runner.mjs";
import { knowledge } from "./knowledge.mjs";
import { scan, questions } from "../lib/scan.mjs";
import {
  discovery,
  promptNames,
  promptText,
  exportPrompts,
  saveConfig,
} from "../lib/setup.mjs";

export function summarize(run) {
  const counts = {
    passed: 0,
    failed: 0,
    skipped: 0,
    pending: 0,
    running: 0,
    interrupted: 0,
    cancelled: 0,
  };
  for (const test of run.tests) {
    const status = test.status === "timedOut" ? "failed" : test.status;
    counts[status] = (counts[status] || 0) + 1;
  }
  const { tests, logs, ...summary } = run;
  return {
    ...summary,
    counts,
    total: tests.length,
    testIds: tests.map((t) => t.id),
    duration: run.startedAt
      ? new Date(run.finishedAt || Date.now()).getTime() -
        new Date(run.startedAt).getTime()
      : 0,
  };
}

export async function createApp({
  ctx,
  data = ctx.data,
  catalog = new Catalog(ctx),
  port = 4173,
}) {
  const app = Fastify({ logger: false, bodyLimit: 256 * 1024 });
  const store = new Store(data);
  const runner = new Runner(store, catalog, data, ctx);
  let enqueueChain = Promise.resolve();
  const clients = new Set();
  const allowedHosts = new Set([
    `localhost:${port}`,
    `127.0.0.1:${port}`,
    "localhost:5173",
    "127.0.0.1:5173",
  ]);
  app.addHook("onRequest", async (req, reply) => {
    if (!allowedHosts.has(req.headers.host))
      return reply
        .code(403)
        .send({ error: "This dashboard accepts localhost requests only." });
    const origin = req.headers.origin;
    if (origin && ![...allowedHosts].some((h) => origin === `http://${h}`))
      return reply
        .code(403)
        .send({ error: "Requests from another website are not allowed." });
    if (
      !["GET", "HEAD"].includes(req.method) &&
      req.headers["x-dashboard-request"] !== "1"
    )
      return reply
        .code(403)
        .send({ error: "Missing dashboard request header." });
    reply.header("X-Content-Type-Options", "nosniff");
    reply.header("Referrer-Policy", "no-referrer");
    reply.header("X-Frame-Options", "DENY");
    if (req.url.startsWith("/api/")) reply.header("Cache-Control", "no-store");
    if (req.url.startsWith("/artifacts/")) {
      const normalized = decodeURIComponent(
        new URL(req.url, "http://localhost").pathname,
      );
      if (
        normalized.includes("..") ||
        normalized.includes("\\") ||
        !/^\/artifacts\/[a-f0-9-]{36}\/(report|results)\//.test(normalized)
      )
        return reply.code(404).send({ error: "Artifact not found." });
    }
  });
  app.setErrorHandler((error, _req, reply) =>
    reply.code(error.statusCode || 500).send({ error: redact(error.message) }),
  );
  app.get("/api/health", async () => ({
    ok: true,
    name: "QA dashboard",
    version: VERSION,
    workspace: ctx.config.name,
    root: ctx.root,
  }));
  app.get("/api/catalog", async () => catalog.get());
  app.post("/api/catalog/refresh", async () => catalog.get(true));
  app.get("/api/knowledge", async () => knowledge(ctx));
  app.get("/api/runs", async () => store.runs().map(summarize));
  app.get("/api/runs/:id", async (req) => {
    const run = store.get(req.params.id);
    if (!run) throw httpError("Run not found.", 404);
    return { ...run, ...summarize(run), tests: run.tests };
  });
  app.get("/api/runs/:id/export", async (req, reply) => {
    const run = store.get(req.params.id);
    if (!run) throw httpError("Run not found.", 404);
    return reply
      .header(
        "Content-Disposition",
        `attachment; filename="qa-run-${run.id.slice(0, 8)}.json"`,
      )
      .type("application/json")
      .send(JSON.stringify(run, null, 2));
  });
  app.post("/api/runs/preview", async (req) => {
    const snapshot = await catalog.get(true);
    const selected = validateSelection(req.body, snapshot);
    const { tests, additional } = executionPlan(
      snapshot,
      req.body.environment,
      selected,
    );
    const previous = store
      .runs()
      .filter(
        (r) => r.environment === req.body.environment && r.status === "passed",
      );
    let estimatedMs = 0;
    let measured = 0;
    for (const test of tests) {
      const result = previous
        .flatMap((r) => r.tests)
        .find((t) => t.id === test.id && t.duration > 0);
      if (result) {
        estimatedMs += result.duration;
        measured++;
      }
    }
    return {
      count: tests.length,
      selectedCount: selected.length,
      additional: additional.map((t) => ({
        id: t.id,
        name: t.name,
        project: t.project,
      })),
      estimatedMs: measured === tests.length ? estimatedMs : null,
      knownIssues: tests.filter((t) => t.knownIssue).length,
      profile: snapshot.profiles.find((p) => p.id === req.body.environment),
    };
  });
  app.post("/api/runs", async (req, reply) => {
    const task = enqueueChain.then(() => runner.enqueue(req.body));
    enqueueChain = task.catch(() => {});
    return reply.code(201).send(summarize(await task));
  });
  app.post("/api/runs/:id/cancel", async (req) =>
    summarize(await runner.cancel(req.params.id)),
  );
  app.get("/api/suites", async () => store.suites());
  app.post("/api/suites", async (req) => {
    const input = req.body;
    if (
      !input ||
      typeof input.name !== "string" ||
      !input.name.trim() ||
      input.name.length > 80
    )
      throw httpError("Give the suite a name (up to 80 characters).");
    const snapshot = await catalog.get();
    if (
      !Array.isArray(input.testIds) ||
      !input.testIds.length ||
      input.testIds.some((id) => !snapshot.tests.some((t) => t.id === id))
    )
      throw httpError("Select valid tests for this suite.");
    const suite = {
      id: randomUUID(),
      name: input.name.trim(),
      testIds: [...new Set(input.testIds)],
      createdAt: new Date().toISOString(),
      kind: "saved",
    };
    store.saveSuite(suite);
    return suite;
  });
  app.delete("/api/suites/:id", async (req) => {
    store.deleteSuite(req.params.id);
    return { ok: true };
  });
  app.get("/api/settings", async () => ({
    node: process.version,
    playwright: ctx.version,
    packageVersion: VERSION,
    name: ctx.config.name,
    maxConcurrentRuns: 1,
    defaultWorkers: ctx.config.execution.workers,
    retries: ctx.config.execution.retries,
    timeoutMs: ctx.config.execution.timeoutMs,
    trace: "Retained on failure",
    dataDirectory: data,
    storageBytes: directorySize(data),
    retention:
      "History and artifacts are kept locally until you remove them. No automatic deletion.",
    connections: { jira: false, github: false, ai: false },
  }));
  app.get("/api/setup", async () => {
    const inventory = scan(ctx.root),
      snapshot = await catalog.get();
    return {
      config: ctx.config,
      root: ctx.root,
      inventory,
      profiles: snapshot.profiles,
      warnings: snapshot.warnings,
      questions: questions(ctx, snapshot, inventory),
      prompts: promptNames(),
    };
  });
  app.post("/api/setup/discover", async () => discovery(ctx, catalog));
  app.get("/api/setup/prompts/:name", async (req) => ({
    text: promptText(ctx, req.params.name),
  }));
  app.post("/api/setup/prompts/export", async () => ({
    directory: exportPrompts(ctx),
  }));
  app.post("/api/setup/config", async (req) => {
    if (store.runs().some((r) => ACTIVE.includes(r.status)) || runner.pumping)
      throw httpError(
        "Wait for active runs to finish before changing configuration.",
        409,
      );
    if (!req.body?.config || req.body.acknowledge !== true)
      throw httpError("Review the configuration before saving.");
    saveConfig(ctx, req.body.config);
    catalog.cache = null;
    return { ok: true };
  });
  app.get("/api/events", (req, reply) => {
    reply.hijack();
    reply.raw.writeHead(200, {
      "Content-Type": "text/event-stream",
      "Cache-Control": "no-cache",
      Connection: "keep-alive",
      "X-Content-Type-Options": "nosniff",
    });
    reply.raw.write("event: ready\ndata: {}\n\n");
    clients.add(reply.raw);
    const heartbeat = setInterval(
      () => reply.raw.write(": heartbeat\n\n"),
      15000,
    );
    req.raw.on("close", () => {
      clients.delete(reply.raw);
      clearInterval(heartbeat);
    });
  });
  runner.on("update", (event) => {
    for (const client of clients)
      client.write(`event: update\ndata: ${JSON.stringify(event)}\n\n`);
  });
  fs.mkdirSync(path.join(data, "runs"), { recursive: true });
  app.get("/artifacts/:id/report/trace/*", (req, reply) => {
    const run = store.get(req.params.id);
    if (!run?.reportAvailable)
      return reply.code(404).send({ error: "Run report not found." });
    return reply.sendFile(
      req.params["*"] || "index.html",
      path.join(ctx.coreDirectory, "lib/vite/traceViewer"),
    );
  });
  await app.register(staticFiles, {
    root: path.join(data, "runs"),
    prefix: "/artifacts/",
    decorateReply: false,
    index: ["index.html"],
    dotfiles: "deny",
  });
  if (fs.existsSync(path.join(DASHBOARD, "dist/index.html"))) {
    await app.register(staticFiles, {
      root: path.join(DASHBOARD, "dist"),
      prefix: "/",
      index: ["index.html"],
    });
    app.setNotFoundHandler((req, reply) =>
      req.url.startsWith("/api/") || req.url.startsWith("/artifacts/")
        ? reply.code(404).send({ error: "Not found." })
        : reply.sendFile("index.html"),
    );
  } else
    app.get("/", async () => ({
      message: "Build the dashboard first: npm run build",
    }));
  app.addHook("onClose", async () => {
    for (const client of clients) client.end();
    await runner.shutdown();
    store.close();
  });
  return { app, store, runner, catalog };
}

function directorySize(dir) {
  let size = 0;
  for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
    const file = path.join(dir, entry.name);
    if (entry.isSymbolicLink()) continue;
    size += entry.isDirectory() ? directorySize(file) : fs.statSync(file).size;
  }
  return size;
}
