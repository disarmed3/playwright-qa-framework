import { execFile } from "node:child_process";
import { promisify } from "node:util";
import fs from "node:fs";
import path from "node:path";
import os from "node:os";
import {
  DASHBOARD,
  inside,
  testEnvironment,
  redact,
  httpError,
} from "./config.mjs";
import { fingerprint } from "../lib/files.mjs";
const exec = promisify(execFile);
export async function discover(ctx, environment, selectors) {
  const temp = fs.mkdtempSync(
    path.join(os.tmpdir(), "qa-dashboard-discovery-"),
  );
  const output = path.join(temp, "catalog.json");
  try {
    const args = [
      ctx.cli,
      "test",
      "--config",
      inside(ctx.root, ctx.config.playwright.config),
      "--list",
      "--forbid-only",
      "--reporter",
      path.join(DASHBOARD, "server/discovery-reporter.mjs"),
    ];
    if (selectors) {
      const list = path.join(temp, "selection.txt");
      fs.writeFileSync(list, selectors.join("\n") + "\n");
      args.push("--test-list", list);
    }
    try {
      await exec(process.execPath, args, {
        cwd: ctx.root,
        env: testEnvironment(ctx, environment, {
          DASHBOARD_DISCOVERY_FILE: output,
        }),
        windowsHide: true,
        timeout: 60000,
        maxBuffer: 4 * 1024 * 1024,
      });
    } catch (error) {
      if (!fs.existsSync(output))
        throw httpError(
          "Playwright discovery failed: " +
            redact(error.stderr || error.message).slice(0, 2500),
        );
    }
    const report = JSON.parse(fs.readFileSync(output, "utf8"));
    if (report.errors?.length || !report.tests)
      throw httpError(
        "Playwright discovery failed: " +
          redact(report.errors?.join("\n") || "No discovery report."),
      );
    for (const t of report.tests)
      if (/\r|\n/.test(t.selector))
        throw httpError(
          "Multiline test titles are unsupported by exact file-list selection. Use the framework CLI.",
        );
    return report;
  } finally {
    if (
      path
        .resolve(temp)
        .startsWith(
          path.resolve(os.tmpdir()) + path.sep + "qa-dashboard-discovery-",
        )
    )
      fs.rmSync(temp, { recursive: true, force: true });
  }
}
export function matches(test, filter = {}) {
  return (
    (!filter.tags?.length ||
      filter.tags.some((t) => test.tags.includes(t.replace(/^@/, "")))) &&
    (!filter.files?.length ||
      filter.files.some((f) => test.sourceFile.startsWith(f))) &&
    (!filter.products?.length || filter.products.includes(test.product)) &&
    (!filter.layers?.length || filter.layers.includes(test.layer)) &&
    (!filter.projects?.length || filter.projects.includes(test.project))
  );
}
function classify(row, ctx) {
  const sourceFile = path
    .relative(ctx.root, row.absoluteFile)
    .replaceAll("\\", "/");
  const rule = [...ctx.config.classifications]
    .reverse()
    .find((r) => sourceFile.startsWith(r.pathPrefix));
  let layer = rule?.layer;
  if (!layer)
    layer = /(?:^|\/)(?:api|api-tests)(?:\/|\.)/.test(sourceFile)
      ? "api"
      : /(?:^|\/)(?:db|database)(?:\/|\.)/.test(sourceFile)
        ? "db"
        : /(?:^|\/)(?:ui|e2e)(?:\/|\.)/.test(sourceFile)
          ? "ui"
          : "other";
  const label = ctx.config.labels[sourceFile + "::" + row.title] || {};
  return {
    ...row,
    sourceFile,
    layer,
    product: rule?.product || "General",
    feature: label.feature || rule?.feature || row.groups[0] || "Other checks",
    name:
      label.name ||
      row.title
        .replace(/⚠️?\s*/g, "")
        .replace(/\s*\(TC-[^)]*\)/g, "")
        .trim(),
    description: label.description || "",
    classificationSource: rule
      ? "Configuration"
      : layer === "other"
        ? "Unclassified"
        : "Path convention",
    cases: [...new Set(row.title.match(/TC-[A-Z]+-\d+[a-z]?/g) || [])],
    tags: (row.tags || []).map((t) => t.replace(/^@/, "")),
    knownIssue: row.title.includes("⚠"),
  };
}
export class Catalog {
  cache = null;
  pending = null;
  constructor(ctx) {
    this.ctx = ctx;
  }
  async get(force = false) {
    if (this.pending) return this.pending;
    if (!force && this.cache && Date.now() - this.cache.checkedAt < 15000)
      return this.cache;
    this.pending = this.refresh(force).finally(() => {
      this.pending = null;
    });
    return this.pending;
  }
  async refresh(force) {
    const ctx = this.ctx;
    ctx.reload();
    const version = fingerprint(ctx.root, ctx.config);
    if (!force && this.cache?.version === version) {
      this.cache.checkedAt = Date.now();
      return this.cache;
    }
    const reports = await Promise.all(
      ctx.config.environments.map((p) =>
        discover(ctx, p.id).then((report) => ({ profile: p, report })),
      ),
    );
    const tests = new Map();
    const warnings = [];
    const browserStates = Object.fromEntries(
      ["chromium", "firefox", "webkit"].map((name) => [
        name,
        fs.existsSync(ctx.browsers[name].executablePath()),
      ]),
    );
    for (const { report } of reports)
      for (const row of report.tests)
        if (!tests.has(row.id))
          tests.set(row.id, { ...classify(row, ctx), availability: {} });
    const profiles = reports.map(({ profile: p, report }) => {
      const rows = new Map(report.tests.map((t) => [t.id, t]));
      for (const test of tests.values()) {
        const row = rows.get(test.id);
        const project = report.projects.find((v) => v.name === test.project);
        const missing = [
          ...p.requiredEnv,
          ...ctx.config.prerequisites
            .filter((r) => test.sourceFile.startsWith(r.pathPrefix))
            .flatMap((r) => r.requiredEnv),
        ].filter((k) => !process.env[k] && !p.env[k]);
        const repeated = report.projects.some((v) => v.repeatEach !== 1);
        const reason = !p.enabled
          ? "Review and enable this environment in Setup."
          : !row
            ? "Not collected in this environment."
            : row.expectedStatus === "skipped"
              ? row.annotations
                  ?.filter((a) => a.type === "skip")
                  .map((a) => a.description)
                  .filter(Boolean)
                  .join(" ") || "Skipped by the framework."
              : missing.length
                ? "Missing environment variables: " + missing.join(", ")
                : p.production &&
                    (!p.allowedTags.some((tag) => test.tags.includes(tag)) ||
                      !p.approvedFiles.includes(test.sourceFile))
                  ? "Not in the reviewed production file and tag allowlists."
                  : repeated
                    ? "repeatEach > 1 is unsupported by this release. Use the framework CLI."
                    : test.layer === "ui" &&
                        project &&
                        !project.channel &&
                        !browserStates[project.browserName]
                      ? project.browserName + " browser is not installed."
                      : "";
        test.availability[p.id] = {
          allowed: !reason,
          reason,
          expectedStatus: row?.expectedStatus,
        };
      }
      if (
        report.globalSetup?.length ||
        report.globalTeardown?.length ||
        report.webServer
      )
        warnings.push(
          p.name +
            ": the framework declares global setup, teardown, or a web server. These run according to its configuration.",
        );
      const urls = [
        ...new Set(report.projects.map((v) => v.baseURL).filter(Boolean)),
      ];
      if (p.url && urls.length && !urls.includes(p.url))
        warnings.push(
          p.name +
            ": configured URL differs from discovered Playwright baseURL. Review the environment mapping.",
        );
      return {
        id: p.id,
        name: p.name,
        description: p.description,
        enabled: p.enabled,
        production: p.production,
        url: urls.length === 1 ? safeUrl(urls[0]) : p.url || "",
        targets: urls.map(safeUrl),
        projects: report.projects.map(({ testDir, outputDir, ...v }) => ({
          ...v,
          baseURL: safeUrl(v.baseURL),
        })),
      };
    });
    const rows = [...tests.values()].map(
      ({ absoluteFile, annotations, ...row }) => row,
    );
    const suites = ctx.config.suites
      .map((s) => ({
        ...s,
        testIds: rows.filter((t) => matches(t, s.filter)).map((t) => t.id),
      }))
      .filter((s) => s.id === "all" || s.testIds.length);
    this.cache = {
      tests: rows,
      version,
      name: ctx.config.name,
      defaultEnvironment: ctx.config.defaultEnvironment,
      profiles,
      suites,
      fileCount: new Set(rows.map((t) => t.sourceFile)).size,
      refreshedAt: new Date().toISOString(),
      checkedAt: Date.now(),
      browserReady: browserStates.chromium,
      browsers: browserStates,
      databaseReady: !ctx.config.prerequisites.some((p) =>
        p.requiredEnv.some((key) => !process.env[key]),
      ),
      warnings: [...new Set(warnings)],
    };
    return this.cache;
  }
}
export function safeUrl(value) {
  try {
    const u = new URL(value);
    return u.origin + u.pathname;
  } catch {
    return "";
  }
}
export function executionPlan(snapshot, environment, selected) {
  const profile = snapshot.profiles.find((p) => p.id === environment);
  if (!profile) throw httpError("Unknown environment.");
  const projects = new Set(selected.map((t) => t.project));
  const extraProjects = new Set();
  const visit = (name, trail = new Set()) => {
    if (trail.has(name)) throw httpError("Project dependency cycle detected.");
    const p = profile.projects.find((v) => v.name === name);
    if (!p) throw httpError("A project is missing from discovery.");
    for (const dependency of p.dependencies || []) {
      extraProjects.add(dependency);
      visit(dependency, new Set([...trail, name]));
    }
    if (p.teardown) extraProjects.add(p.teardown);
  };
  projects.forEach((p) => visit(p));
  const tests = [
    ...new Map(
      [
        ...selected,
        ...snapshot.tests.filter(
          (t) => extraProjects.has(t.project) && t.availability[environment],
        ),
      ].map((t) => [t.id, t]),
    ).values(),
  ];
  const blocked = tests.filter(
    (t) =>
      !t.availability[environment]?.allowed &&
      t.availability[environment]?.expectedStatus !== "skipped",
  );
  if (blocked.length)
    throw httpError(
      "Required setup/teardown or selected checks are unavailable: " +
        blocked
          .map((t) => t.name)
          .slice(0, 3)
          .join(", "),
    );
  return {
    tests,
    additional: tests.filter((t) => !selected.some((s) => s.id === t.id)),
  };
}
