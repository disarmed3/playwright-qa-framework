import path from "node:path";
import fs from "node:fs";
import { fileURLToPath } from "node:url";
import { createRequire } from "node:module";
export const DASHBOARD = path.resolve(
  path.dirname(fileURLToPath(import.meta.url)),
  "..",
);
export const VERSION = "0.1.3";
export const CONFIG_NAME = "qa-dashboard.config.json";
const sensitive =
  /TOKEN|PASSWORD|SECRET|DATABASE_URL|API_KEY|PRIVATE_KEY|CREDENTIAL/i;
export function httpError(message, statusCode = 400) {
  return Object.assign(new Error(message), { statusCode });
}
export function redact(value) {
  let text = String(value ?? "").replace(/\x1b\[[0-9;]*m/g, "");
  for (const [key, secret] of Object.entries(process.env))
    if (sensitive.test(key) && secret?.length > 4)
      text = text.split(secret).join("[redacted]");
  return text
    .replace(/(postgres(?:ql)?:\/\/)[^\s"']+/gi, "$1[redacted]")
    .replace(/(Bearer\s+)[\w.\-]+/gi, "$1[redacted]")
    .replace(/\b(xox[baprs]-[\w-]+|ATATT[\w-]+)\b/g, "[redacted]");
}
export function inside(root, relative, { exists = false } = {}) {
  if (typeof relative !== "string" || path.isAbsolute(relative))
    throw httpError("Use a project-relative path.");
  const file = path.resolve(root, relative);
  if (file !== root && !file.startsWith(root + path.sep))
    throw httpError("A configured path leaves the framework directory.");
  let ancestor = file;
  while (!fs.existsSync(ancestor) && ancestor !== root)
    ancestor = path.dirname(ancestor);
  const real = fs.realpathSync(ancestor);
  if (real !== root && !real.startsWith(root + path.sep))
    throw httpError("A configured symlink leaves the framework directory.");
  if (!fs.existsSync(file) && exists)
    throw httpError("Missing project file: " + relative);
  return file;
}
export function defaults(
  name = "QA workspace",
  config = "playwright.config.ts",
) {
  return {
    schemaVersion: 1,
    name,
    playwright: { config },
    defaultEnvironment: "default",
    environments: [
      {
        id: "default",
        name: "Framework default",
        description:
          "Uses the framework configuration. Review the target before enabling execution.",
        enabled: false,
        production: false,
        env: {},
        requiredEnv: [],
        allowedTags: [],
        approvedFiles: [],
      },
    ],
    classifications: [],
    suites: [
      {
        id: "all",
        name: "Full test suite",
        description: "Every available check in this framework.",
        filter: {},
      },
      {
        id: "smoke",
        name: "Quick health check",
        description: "Checks explicitly tagged smoke.",
        filter: { tags: ["smoke"] },
      },
      {
        id: "regression",
        name: "Regression checks",
        description: "Checks explicitly tagged regression.",
        filter: { tags: ["regression"] },
      },
      {
        id: "e2e",
        name: "User journeys",
        description: "Checks explicitly tagged e2e.",
        filter: { tags: ["e2e"] },
      },
    ],
    labels: {},
    sources: { journals: [], cases: [] },
    prerequisites: [],
    execution: { workers: 1, retries: 0, timeoutMs: 900000 },
  };
}
function strings(value, label) {
  if (
    !Array.isArray(value) ||
    value.some((v) => typeof v !== "string" || v.length > 500)
  )
    throw httpError(label + " must be a list of strings.");
}
export function validateConfig(input, root) {
  if (!input || input.schemaVersion !== 1)
    throw httpError("Configuration requires schemaVersion: 1.");
  const c = structuredClone(input);
  for (const key of Object.keys(c))
    if (
      ![
        "$schema",
        "schemaVersion",
        "name",
        "playwright",
        "defaultEnvironment",
        "environments",
        "classifications",
        "suites",
        "labels",
        "sources",
        "prerequisites",
        "execution",
      ].includes(key)
    )
      throw httpError("Unknown configuration field: " + key);
  if (typeof c.name !== "string" || !c.name.trim() || c.name.length > 100)
    throw httpError("Choose a workspace name of 1–100 characters.");
  inside(root, c.playwright?.config, { exists: true });
  if (
    !Array.isArray(c.environments) ||
    !c.environments.length ||
    c.environments.length > 8
  )
    throw httpError("Configure one to eight environments.");
  const ids = new Set();
  for (const p of c.environments) {
    if (!/^[a-z][a-z0-9-]{0,39}$/.test(p.id) || ids.has(p.id))
      throw httpError("Environment IDs must be unique, lowercase names.");
    ids.add(p.id);
    if (
      typeof p.name !== "string" ||
      !p.name.trim() ||
      typeof p.enabled !== "boolean" ||
      typeof p.production !== "boolean"
    )
      throw httpError(
        "Each environment needs a name, enabled flag, and production flag.",
      );
    p.description ||= "";
    p.env ||= {};
    p.requiredEnv ||= [];
    p.allowedTags ||= [];
    p.approvedFiles ||= [];
    for (const field of ["requiredEnv", "allowedTags", "approvedFiles"])
      strings(p[field], field);
    for (const file of p.approvedFiles) inside(root, file);
    if (!p.env || typeof p.env !== "object" || Array.isArray(p.env))
      throw httpError("Environment values must be an object.");
    for (const [key, value] of Object.entries(p.env)) {
      if (
        !/^[A-Z][A-Z0-9_]*$/.test(key) ||
        /^(NODE_OPTIONS|PATH|PATHEXT|DASHBOARD_.*|PLAYWRIGHT_.*|PWDEBUG)$/.test(
          key,
        )
      )
        throw httpError("Unsupported environment override: " + key);
      if (sensitive.test(key))
        throw httpError(
          "Keep " +
            key +
            " in the process environment, not dashboard configuration.",
        );
      if (
        typeof value !== "string" ||
        value.length > 2000 ||
        /:\/\/[^/\s]+:[^/\s]+@/.test(value)
      )
        throw httpError("Use plain, non-secret configuration values.");
    }
    if (p.url) {
      let url;
      try {
        url = new URL(p.url);
      } catch {
        throw httpError("Environment URL must be an HTTP(S) address.");
      }
      if (
        !["http:", "https:"].includes(url.protocol) ||
        url.username ||
        url.password ||
        url.search ||
        url.hash
      )
        throw httpError(
          "Environment URLs cannot contain credentials, query strings, or fragments.",
        );
      if (p.urlEnv && p.env[p.urlEnv] !== p.url)
        throw httpError(
          "The displayed URL must match its environment variable override.",
        );
    }
    if (
      p.production &&
      p.enabled &&
      (!p.allowedTags.length || !p.approvedFiles.length)
    )
      throw httpError(
        "Production execution needs both reviewed file and tag allowlists.",
      );
  }
  if (!ids.has(c.defaultEnvironment))
    throw httpError("The default environment does not exist.");
  c.classifications ||= [];
  c.suites ||= defaults().suites;
  c.labels ||= {};
  c.sources ||= { journals: [], cases: [] };
  c.prerequisites ||= [];
  if (
    !Array.isArray(c.classifications) ||
    !Array.isArray(c.suites) ||
    !Array.isArray(c.prerequisites)
  )
    throw httpError("Rules and suites must be arrays.");
  const suiteIds = new Set();
  for (const s of c.suites) {
    if (
      !/^[a-z][a-z0-9-]*$/.test(s.id) ||
      suiteIds.has(s.id) ||
      typeof s.name !== "string" ||
      !s.name.trim()
    )
      throw httpError("Suites require unique IDs and names.");
    suiteIds.add(s.id);
    s.filter ||= {};
    for (const [k, v] of Object.entries(s.filter)) {
      if (!["tags", "files", "products", "layers", "projects"].includes(k))
        throw httpError("Unsupported suite filter: " + k);
      strings(v, k);
    }
  }
  for (const r of c.classifications) {
    if (
      typeof r.pathPrefix !== "string" ||
      r.pathPrefix.includes("..") ||
      r.pathPrefix.includes("\\")
    )
      throw httpError(
        "Classification rules use relative forward-slash path prefixes.",
      );
    if (r.layer && !["ui", "api", "db", "other"].includes(r.layer))
      throw httpError("Unknown test layer.");
  }
  if (!c.labels || typeof c.labels !== "object" || Array.isArray(c.labels))
    throw httpError("Labels must be an object.");
  for (const label of Object.values(c.labels)) {
    if (!label || typeof label !== "object" || Array.isArray(label))
      throw httpError("Each label must be an object.");
    for (const [key, value] of Object.entries(label))
      if (
        !["name", "description", "feature"].includes(key) ||
        typeof value !== "string" ||
        value.length > 2000
      )
        throw httpError(
          "Labels accept name, description, and feature text only.",
        );
  }
  for (const kind of ["journals", "cases"]) {
    c.sources[kind] ||= [];
    strings(c.sources[kind], kind);
    c.sources[kind].forEach((file) => inside(root, file));
  }
  for (const p of c.prerequisites) {
    strings(p.requiredEnv, "requiredEnv");
    if (typeof p.pathPrefix !== "string")
      throw httpError("Prerequisites need a path prefix.");
  }
  c.execution = { workers: 1, retries: 0, timeoutMs: 900000, ...c.execution };
  if (
    ![1, 2, 4].includes(c.execution.workers) ||
    ![0, 1, 2].includes(c.execution.retries) ||
    !Number.isInteger(c.execution.timeoutMs) ||
    c.execution.timeoutMs < 1000 ||
    c.execution.timeoutMs > 3600000
  )
    throw httpError("Invalid execution defaults.");
  return c;
}
export function createWorkspace(directory, { configuration } = {}) {
  const root = fs.realpathSync(path.resolve(directory));
  const configPath = inside(root, CONFIG_NAME);
  if (!configuration && !fs.existsSync(configPath))
    throw httpError(
      "Initialize this framework first: qa-dashboard init --root <framework>",
    );
  const req = createRequire(path.join(root, "package.json"));
  let playwrightPackage, corePackage;
  try {
    playwrightPackage = req.resolve("@playwright/test/package.json");
    corePackage = req.resolve("playwright-core/package.json");
  } catch {
    throw httpError(
      "Install @playwright/test in the target framework before using the dashboard.",
    );
  }
  const version = JSON.parse(
    fs.readFileSync(playwrightPackage, "utf8"),
  ).version;
  const [major, minor, patch] = version.split(".").map(Number);
  if (major !== 1 || minor < 61 || (minor === 61 && patch < 1))
    throw httpError(
      "Playwright " +
        version +
        " is unsupported. Requires 1.61.1 or later in major 1.",
    );
  const ctx = {
    root,
    configPath,
    data: inside(root, ".qa-dashboard/data"),
    cli: path.join(path.dirname(playwrightPackage), "cli.js"),
    version,
    coreDirectory: path.dirname(corePackage),
    browsers: req("playwright-core"),
    reload() {
      this.config = validateConfig(
        configuration || JSON.parse(fs.readFileSync(configPath, "utf8")),
        root,
      );
      return this.config;
    },
  };
  ctx.reload();
  return ctx;
}
export function testEnvironment(ctx, profileId, extra = {}) {
  const profile = ctx.config.environments.find((p) => p.id === profileId);
  if (!profile) throw httpError("Unknown environment.");
  const env = { ...process.env };
  const profileKeys = new Set(
    ctx.config.environments.flatMap((p) => Object.keys(p.env)),
  );
  for (const key of Object.keys(env))
    if (
      /^(PLAYWRIGHT_|PWDEBUG$|NODE_OPTIONS$|DASHBOARD_)/.test(key) ||
      profileKeys.has(key)
    )
      delete env[key];
  return { ...env, ...profile.env, FORCE_COLOR: "0", ...extra };
}
