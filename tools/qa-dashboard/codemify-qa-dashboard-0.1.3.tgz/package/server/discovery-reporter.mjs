import fs from "node:fs";
import path from "node:path";
export default class DiscoveryReporter {
  errors = [];
  onBegin(config, suite) {
    this.report = {
      rootDir: config.rootDir,
      globalSetup: config.globalSetup,
      globalTeardown: config.globalTeardown,
      webServer: Boolean(config.webServer),
      projects: config.projects.map((p) => ({
        name: p.name,
        dependencies: p.dependencies,
        teardown: p.teardown,
        repeatEach: p.repeatEach,
        testDir: p.testDir,
        browserName: p.use.browserName || "chromium",
        channel: p.use.channel || "",
        baseURL: p.use.baseURL || "",
        outputDir: p.outputDir,
      })),
      tests: suite.allTests().map((t) => {
        const p = t.parent.project();
        const groups = t.titlePath().slice(3, -1);
        const file = path
          .relative(config.rootDir, t.location.file)
          .replaceAll("\\", "/");
        return {
          id: t.id,
          title: t.title,
          file,
          absoluteFile: t.location.file,
          line: t.location.line,
          column: t.location.column,
          groups,
          project: p?.name || "",
          tags: t.tags,
          expectedStatus: t.expectedStatus,
          annotations: t.annotations,
          selector:
            (p?.name ? "[" + p.name + "] › " : "") +
            file +
            ":" +
            t.location.line +
            ":" +
            t.location.column +
            " › " +
            [...groups, t.title].join(" › "),
        };
      }),
    };
  }
  onError(error) {
    this.errors.push(error.message || String(error));
  }
  onEnd() {
    fs.writeFileSync(
      process.env.DASHBOARD_DISCOVERY_FILE,
      JSON.stringify({ ...this.report, errors: this.errors }),
    );
  }
  printsToStdio() {
    return false;
  }
}
