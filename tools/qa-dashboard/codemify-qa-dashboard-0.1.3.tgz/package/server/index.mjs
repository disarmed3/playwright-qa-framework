import fs from "node:fs";
import path from "node:path";
import net from "node:net";
import { createApp } from "./app.mjs";
export async function startServer(ctx, { port = 4173 } = {}) {
  const probe = net.createServer();
  await new Promise((resolve, reject) => {
    probe.once("error", reject);
    probe.listen(port, "127.0.0.1", resolve);
  }).catch((error) => {
    throw new Error(
      error.code === "EADDRINUSE"
        ? "Port " + port + " is in use. Choose another with --port."
        : error.message,
    );
  });
  await new Promise((resolve) => probe.close(resolve));
  fs.mkdirSync(ctx.data, { recursive: true });
  const lock = path.join(ctx.data, "server.lock");
  if (fs.existsSync(lock)) {
    const owner = Number(fs.readFileSync(lock, "utf8"));
    let alive = false;
    if (Number.isSafeInteger(owner) && owner > 0) {
      try {
        process.kill(owner, 0);
        alive = true;
      } catch (e) {
        alive = e.code !== "ESRCH";
      }
    }
    if (alive)
      throw new Error(
        "This framework already has an active dashboard. See .qa-dashboard/data/server.json.",
      );
    fs.unlinkSync(lock);
  }
  fs.writeFileSync(lock, String(process.pid), { flag: "wx" });
  const release = () => {
    try {
      if (fs.readFileSync(lock, "utf8") === String(process.pid))
        fs.unlinkSync(lock);
    } catch {
      /* Already released. */
    }
  };
  process.once("exit", release);
  let instance;
  const handlers = [];
  try {
    const result = await createApp({ ctx, port });
    instance = result.app;
    result.app.addHook("onClose", async () => {
      release();
      process.removeListener("exit", release);
      for (const [signal, handler] of handlers)
        process.removeListener(signal, handler);
    });
    await result.app.listen({ port, host: "127.0.0.1" });
    fs.writeFileSync(
      path.join(ctx.data, "server.json"),
      JSON.stringify({
        pid: process.pid,
        port,
        root: ctx.root,
        startedAt: new Date().toISOString(),
      }),
    );
    console.log(
      "QA dashboard · " +
        ctx.config.name +
        "\nhttp://localhost:" +
        port +
        "\nFramework: " +
        ctx.root,
    );
    let closing = false;
    for (const signal of ["SIGINT", "SIGTERM"]) {
      const handler = async () => {
        if (closing) return;
        closing = true;
        await result.app.close();
        process.exit(0);
      };
      handlers.push([signal, handler]);
      process.on(signal, handler);
    }
    return result;
  } catch (error) {
    if (instance) await instance.close();
    process.removeListener("exit", release);
    release();
    throw error;
  }
}
