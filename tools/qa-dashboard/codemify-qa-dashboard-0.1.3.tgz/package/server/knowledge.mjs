import fs from "node:fs";
import path from "node:path";
import { execFile } from "node:child_process";
import { promisify } from "node:util";
import { inside, redact } from "./config.mjs";
import { scan } from "../lib/scan.mjs";
const exec = promisify(execFile);
export async function knowledge(ctx) {
  const journals = [],
    cases = new Map(),
    warnings = [];
  for (const source of ctx.config.sources.journals) {
    const dir = inside(ctx.root, source);
    if (!fs.existsSync(dir)) {
      warnings.push("Optional journal source missing: " + source);
      continue;
    }
    const files = fs.statSync(dir).isDirectory()
      ? fs
          .readdirSync(dir)
          .filter((f) => f.endsWith(".md") && !/^(readme|index)\.md$/i.test(f))
          .map((f) => path.join(dir, f))
      : [dir];
    for (const file of files.sort().reverse().slice(0, 100)) {
      if (
        fs.lstatSync(file).isSymbolicLink() ||
        fs.statSync(file).size > 1_000_000
      )
        continue;
      const content = redact(fs.readFileSync(file, "utf8"));
      const date =
        path.basename(file).match(/\d{4}-\d{2}-\d{2}/)?.[0] ||
        fs.statSync(file).mtime.toISOString().slice(0, 10);
      content
        .split(/(?=^## )/m)
        .filter((s) => s.trim())
        .forEach((section, i) =>
          journals.push({
            id: source + "/" + path.basename(file) + ":" + i,
            date,
            title: (
              section.match(/^##?\s+(.+)/m)?.[1] || path.basename(file)
            ).replace(/^\d{2}:\d{2}\s*[—–-]\s*/, ""),
            body: section.replace(/^##?[^\n]+\n/, "").trim(),
            source: path.relative(ctx.root, file).replaceAll("\\", "/"),
            type: "journal",
          }),
        );
    }
  }
  for (const source of ctx.config.sources.cases) {
    const file = inside(ctx.root, source);
    if (!fs.existsSync(file)) {
      warnings.push("Optional case catalog missing: " + source);
      continue;
    }
    if (!fs.statSync(file).isFile() || fs.statSync(file).size > 2_000_000)
      continue;
    for (const line of redact(fs.readFileSync(file, "utf8")).split("\n")) {
      const heading = line.match(
        /^(?:#{1,6}\s+|\*\*)?(TC-[A-Z]+-\d+[a-z]?)(?:\s*\([^)]*\))?\*?\*?\s+(.+)/,
      );
      if (heading) {
        cases.set(heading[1], {
          id: heading[1],
          title: heading[2].replace(/\*\*/g, ""),
          source,
        });
        continue;
      }
      const match = line.match(/^\|\s*\*?\*?(TC-[A-Z]+-\d+[a-z]?)\*?\*?\s*\|/);
      if (!match) continue;
      const columns = line
        .split("|")
        .slice(1, -1)
        .map((s) => s.trim());
      cases.set(match[1], {
        id: match[1],
        title: columns.slice(1).find((s) => s.length > 12) || match[1],
        source,
      });
    }
  }
  let commits = [];
  try {
    const { stdout } = await exec(
      "git",
      [
        "-c",
        "safe.directory=" + ctx.root.replaceAll("\\", "/"),
        "log",
        "-35",
        "--format=%h%x1f%as%x1f%an%x1f%s",
      ],
      { cwd: ctx.root, windowsHide: true, timeout: 5000 },
    );
    commits = stdout
      .trim()
      .split("\n")
      .filter(Boolean)
      .map((line) => {
        const [id, date, author, title] = line.split("\x1f");
        return {
          id,
          date,
          author: redact(author),
          title: redact(title),
          type: "commit",
        };
      });
  } catch {
    /* Git is optional. */
  }
  return {
    journals: journals.sort((a, b) => b.date.localeCompare(a.date)),
    commits,
    cases: [...cases.values()],
    workflows: scan(ctx.root).workflows,
    warnings,
    asOf: new Date().toISOString(),
  };
}
