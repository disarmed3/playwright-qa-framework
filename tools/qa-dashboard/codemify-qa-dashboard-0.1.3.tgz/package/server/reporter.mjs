import fs from "node:fs";

// An append-only event file survives a browser disconnect. No terminal-text parsing.
export default class DashboardReporter {
  send(event) {
    if (process.env.DASHBOARD_EVENT_FILE)
      fs.appendFileSync(
        process.env.DASHBOARD_EVENT_FILE,
        JSON.stringify({ ...event, at: new Date().toISOString() }) + "\n",
      );
  }
  onBegin(_config, suite) {
    this.send({ type: "begin", ids: suite.allTests().map((t) => t.id) });
  }
  onTestBegin(test) {
    this.send({ type: "test-start", id: test.id });
  }
  onTestEnd(test, result) {
    this.send({
      type: "test-end",
      id: test.id,
      status: result.status,
      expectedStatus: test.expectedStatus,
      duration: result.duration,
      retry: result.retry,
      error: result.errors
        ?.map((e) => e.message || "")
        .join("\n")
        .slice(0, 16000),
      annotations: test.annotations,
      attachments: result.attachments.map((a) => ({
        name: a.name,
        path: a.path,
        contentType: a.contentType,
      })),
    });
  }
  onError(error) {
    this.send({ type: "error", message: error.message });
  }
  onEnd(result) {
    this.send({ type: "end", status: result.status });
  }
  printsToStdio() {
    return false;
  }
}
