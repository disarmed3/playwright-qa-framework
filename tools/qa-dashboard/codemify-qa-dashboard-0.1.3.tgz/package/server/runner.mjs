import { spawn, execFile } from "node:child_process";
import { promisify } from "node:util";
import fs from "node:fs";
import path from "node:path";
import { randomUUID } from "node:crypto";
import { EventEmitter } from "node:events";
import {
  DASHBOARD,
  inside,
  testEnvironment,
  redact,
  httpError,
} from "./config.mjs";
import { discover, executionPlan } from "./catalog.mjs";

const exec = promisify(execFile);
export const ACTIVE = ["queued", "running", "cancelling"];

export function validateSelection(input, catalog) {
  if (!input || !catalog.profiles.some((p) => p.id === input.environment))
    throw httpError("Choose a valid environment.");
  if (input.catalogVersion !== catalog.version)
    throw httpError(
      "The test catalog changed. Refresh and review your selection.",
      409,
    );
  if (
    !Array.isArray(input.testIds) ||
    !input.testIds.length ||
    input.testIds.length > 1000 ||
    input.testIds.some((id) => typeof id !== "string")
  )
    throw httpError("Select at least one test.");
  const ids = [...new Set(input.testIds)];
  const tests = ids.map((id) => catalog.tests.find((t) => t.id === id));
  if (tests.some((t) => !t))
    throw httpError(
      "A selected test no longer exists. Refresh the catalog.",
      409,
    );
  if (tests.some((t) => !t.availability[input.environment].allowed))
    throw httpError(
      "Some selected tests are unavailable for this environment. Review the selection.",
    );

  if (input.headed !== undefined && typeof input.headed !== "boolean")
    throw httpError("Invalid browser mode.");
  if (input.workers !== undefined && ![1, 2, 4].includes(input.workers))
    throw httpError("Choose 1, 2, or 4 workers.");
  return tests;
}

export class Runner extends EventEmitter {
  current = null;
  pumping = false;
  stopping = false;
  constructor(store, catalog, data, ctx) {
    super();
    this.store = store;
    this.catalog = catalog;
    this.data = data;
    this.ctx = ctx;
    this.cli = ctx.cli;
    for (const run of store.runs().filter((r) => ACTIVE.includes(r.status))) {
      run.status = "interrupted";
      run.finishedAt = new Date().toISOString();
      run.error =
        "The dashboard stopped before this run finished. Review any test data before rerunning.";
      for (const t of run.tests)
        if (["pending", "running"].includes(t.status)) t.status = "interrupted";
      store.put(run);
    }
  }
  publish(run) {
    this.store.put(run);
    this.emit("update", { id: run.id, status: run.status });
  }
  async enqueue(input) {
    const catalog = await this.catalog.get(true);
    const selected = validateSelection(input, catalog);
    const { tests } = executionPlan(catalog, input.environment, selected);
    const existing = this.store.runs().filter((r) => ACTIVE.includes(r.status));
    if (existing.length >= 8)
      throw httpError("The queue is full. Wait for a run to finish.", 409);
    const key = [...tests.map((t) => t.id)].sort().join("|");
    if (
      existing.some(
        (r) =>
          r.environment === input.environment &&
          r.tests
            .map((t) => t.id)
            .sort()
            .join("|") === key,
      )
    )
      throw httpError("This selection is already running or queued.", 409);
    let revision = "unavailable";
    let dirty = false;
    try {
      const options = { cwd: this.ctx.root, windowsHide: true, timeout: 5000 };
      revision = (
        await exec(
          "git",
          [
            "-c",
            `safe.directory=${this.ctx.root.replaceAll("\\", "/")}`,
            "rev-parse",
            "--short",
            "HEAD",
          ],
          options,
        )
      ).stdout.trim();
      dirty = Boolean(
        (
          await exec(
            "git",
            [
              "-c",
              `safe.directory=${this.ctx.root.replaceAll("\\", "/")}`,
              "status",
              "--porcelain",
            ],
            options,
          )
        ).stdout.trim(),
      );
    } catch {
      /* Git metadata is optional. */
    }
    const run = {
      id: randomUUID(),
      name:
        typeof input.name === "string"
          ? input.name.trim().slice(0, 100) || "Custom selection"
          : "Custom selection",
      createdAt: new Date().toISOString(),
      status: "queued",
      environment: input.environment,
      url: catalog.profiles.find((p) => p.id === input.environment).url,
      selectionIds: selected.map((t) => t.id),
      selectionSelectors: selected.map((t) => t.selector),
      headed: Boolean(input.headed),
      workers: input.headed
        ? 1
        : input.workers || this.ctx.config.execution.workers,
      retries: this.ctx.config.execution.retries,
      revision,
      dirty,
      catalogVersion: catalog.version,
      tests: tests.map((t) => ({ ...t, status: "pending", duration: 0 })),
      logs: "",
      error: "",
      reportAvailable: false,
    };
    this.publish(run);
    void this.pump();
    return run;
  }
  async pump() {
    if (this.current || this.pumping || this.stopping) return;
    this.pumping = true;
    let run;
    try {
      run = this.store
        .runs()
        .reverse()
        .find((r) => r.status === "queued");
      if (!run) return;
      // Keep the selection bound to the source version previewed by the user.
      const catalog = await this.catalog.get(true);
      const latest = this.store.get(run.id);
      if (latest.status !== "queued") return;
      if (catalog.version !== run.catalogVersion) {
        run.status = "blocked";
        run.error =
          "Test code changed while this run was queued. Refresh the catalog and create a new run.";
        run.finishedAt = new Date().toISOString();
        this.publish(run);
        return;
      }
      const directory = path.join(this.data, "runs", run.id);
      fs.mkdirSync(directory, { recursive: true });
      const selectionFile = path.join(directory, "selection.txt");
      fs.writeFileSync(selectionFile, run.selectionSelectors.join("\n") + "\n");
      const report = await discover(
        this.ctx,
        run.environment,
        run.selectionSelectors,
      );
      const ids = report.tests
        .map((t) => t.id)
        .sort()
        .join("|");
      if (
        ids !==
        run.tests
          .map((t) => t.id)
          .sort()
          .join("|")
      )
        throw new Error(
          "The executable selection differs from the preview. No tests were run. Refresh the catalog.",
        );
      if (this.store.get(run.id).status !== "queued" || this.stopping) return;
      executionPlan(
        catalog,
        run.environment,
        run.tests.filter((t) => run.selectionIds.includes(t.id)),
      );
      this.launch(run);
    } catch (error) {
      if (run && this.store.get(run.id)?.status === "queued") {
        run.status = "error";
        run.error = redact(error.message);
        run.finishedAt = new Date().toISOString();
        this.publish(run);
      }
    } finally {
      this.pumping = false;
      if (
        !this.current &&
        !this.stopping &&
        this.store.runs().some((r) => r.status === "queued")
      )
        setTimeout(() => void this.pump(), 0);
    }
  }
  launch(run) {
    const directory = path.join(this.data, "runs", run.id);
    fs.mkdirSync(directory, { recursive: true });
    const listFile = path.join(directory, "selection.txt");
    const eventFile = path.join(directory, "events.jsonl");
    fs.writeFileSync(listFile, run.selectionSelectors.join("\n") + "\n");
    const args = [
      this.cli,
      "test",
      "--config",
      inside(this.ctx.root, this.ctx.config.playwright.config),
      "--trace",
      "retain-on-failure",
      "--test-list",
      listFile,
      "--workers",
      String(run.workers),
      "--retries",
      String(run.retries),
      "--forbid-only",
      "--global-timeout",
      String(this.ctx.config.execution.timeoutMs),
      "--output",
      path.join(directory, "results"),
      "--reporter",
      `list,html,json,${path.join(DASHBOARD, "server/reporter.mjs")}`,
    ];
    if (run.headed) args.push("--headed");
    const child = spawn(
      process.execPath,
      [path.join(DASHBOARD, "server/worker.mjs"), ...args],
      {
        cwd: this.ctx.root,
        windowsHide: true,
        shell: false,
        stdio: ["ignore", "pipe", "pipe", "ipc"],
        env: testEnvironment(this.ctx, run.environment, {
          PLAYWRIGHT_HTML_OUTPUT_DIR: path.join(directory, "report"),
          PLAYWRIGHT_HTML_OPEN: "never",
          PLAYWRIGHT_JSON_OUTPUT_FILE: path.join(directory, "report.json"),
          DASHBOARD_EVENT_FILE: eventFile,
        }),
      },
    );
    run.status = "running";
    run.startedAt = new Date().toISOString();
    this.current = {
      child,
      run,
      directory,
      eventFile,
      offset: 0,
      timer: null,
      cancelTimer: null,
    };
    this.publish(run);
    const log = (chunk) => {
      run.logs = (run.logs + redact(chunk.toString())).slice(-64000);
    };
    child.stdout.on("data", log);
    child.stderr.on("data", log);
    this.current.timer = setInterval(() => {
      if (this.drain()) this.publish(run);
    }, 250);
    let finished = false;
    const finish = (code, error) => {
      if (finished) return;
      finished = true;
      const state = this.current;
      if (!state || state.run.id !== run.id) return;
      clearInterval(state.timer);
      clearTimeout(state.cancelTimer);
      this.drain();
      const cancelled = run.status === "cancelling";
      const allDone = run.tests.every(
        (t) => !["pending", "running"].includes(t.status),
      );
      run.status = cancelled
        ? "cancelled"
        : error
          ? "error"
          : code === 0 &&
              allDone &&
              run.tests.length &&
              !run.tests.some((t) => ["failed", "timedOut"].includes(t.status))
            ? run.tests.every((t) => t.status === "skipped")
              ? "skipped"
              : "passed"
            : run.tests.some((t) => ["failed", "timedOut"].includes(t.status))
              ? "failed"
              : "error";
      if (error) run.error = redact(error.message);
      if (!cancelled && !allDone && !run.error)
        run.error =
          "The runner stopped before all selected tests reported a result. Open the technical log for details.";
      for (const t of run.tests)
        if (["pending", "running"].includes(t.status))
          t.status = cancelled ? "cancelled" : "interrupted";
      run.finishedAt = new Date().toISOString();
      run.exitCode = code;
      run.reportAvailable = fs.existsSync(
        path.join(directory, "report/index.html"),
      );
      this.current = null;
      this.publish(run);
      void this.pump();
    };
    child.on("error", (error) => finish(null, error));
    child.on("exit", (code) => finish(code));
    child.on("close", (code) => finish(code));
  }
  drain() {
    const state = this.current;
    if (!state || !fs.existsSync(state.eventFile)) return false;
    const content = fs.readFileSync(state.eventFile, "utf8");
    const end = content.lastIndexOf("\n") + 1;
    if (end <= state.offset) return false;
    const lines = content.slice(state.offset, end).trim().split("\n");
    state.offset = end;
    for (const line of lines) {
      try {
        const event = JSON.parse(line);
        const test = state.run.tests.find((t) => t.id === event.id);
        if (event.type === "begin") {
          const planned = state.run.tests
            .map((t) => t.id)
            .sort()
            .join("|");
          if (event.ids.sort().join("|") !== planned) {
            state.run.error =
              "The runner discovered a different selection. Execution was stopped.";
            void this.cancel(state.run.id);
          }
        }
        if (event.type === "test-start" && test) {
          test.status = "running";
          test.startedAt = event.at;
        }
        if (event.type === "test-end" && test) {
          test.attempts ||= [];
          test.attempts.push({
            status: event.status,
            retry: event.retry || 0,
            duration: event.duration,
          });
          test.expectedFailure = event.expectedStatus === "failed";
          test.status =
            event.status === "failed" && test.expectedFailure
              ? "passed"
              : event.status === "passed" && test.expectedFailure
                ? "failed"
                : event.status;
          test.flaky =
            test.status === "passed" &&
            test.attempts.some((a) =>
              ["failed", "timedOut"].includes(a.status),
            ) &&
            !test.expectedFailure;
          test.duration = event.duration;
          test.error = redact(event.error);
          test.finishedAt = event.at;
          test.attachments = (event.attachments || [])
            .filter(
              (a) =>
                a.path &&
                path
                  .resolve(a.path)
                  .startsWith(path.resolve(state.directory) + path.sep),
            )
            .map((a) => ({
              name: a.name,
              contentType: a.contentType,
              url: `/artifacts/${state.run.id}/${path.relative(state.directory, a.path).replaceAll("\\", "/")}`,
            }));
        }
        if (event.type === "error") state.run.error = redact(event.message);
      } catch {
        /* Keep partial/corrupt events from crashing the supervisor. */
      }
    }
    return true;
  }
  async cancel(id) {
    const run = this.store.get(id);
    if (!run) throw httpError("Run not found.", 404);
    if (run.status === "queued") {
      run.status = "cancelled";
      run.finishedAt = new Date().toISOString();
      run.tests.forEach((t) => {
        t.status = "cancelled";
      });
      this.publish(run);
      return run;
    }
    const state = this.current;
    if (!state || state.run.id !== id || !ACTIVE.includes(run.status))
      return run;
    state.run.status = "cancelling";
    this.publish(state.run);
    if (process.platform === "win32") {
      // Restrict termination to the exact child process and its descendants.
      await exec("taskkill", ["/pid", String(state.child.pid), "/t", "/f"], {
        windowsHide: true,
      }).catch(() => state.child.kill());
    } else {
      state.child.kill("SIGTERM");
      state.cancelTimer = setTimeout(() => state.child.kill("SIGKILL"), 5000);
    }
    return state.run;
  }
  async shutdown() {
    this.stopping = true;
    if (!this.current) return;
    const child = this.current.child;
    let timeout;
    const stopped =
      child.exitCode !== null || child.signalCode !== null
        ? Promise.resolve()
        : new Promise((resolve) => {
            child.once("exit", resolve);
            timeout = setTimeout(resolve, 7000);
          });
    await this.cancel(this.current.run.id);
    await stopped;
    clearTimeout(timeout);
  }
}
