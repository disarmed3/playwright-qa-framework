import { DatabaseSync } from "node:sqlite";
import { mkdirSync } from "node:fs";
import path from "node:path";

export class Store {
  constructor(directory) {
    mkdirSync(directory, { recursive: true });
    this.db = new DatabaseSync(path.join(directory, "history.sqlite"));
    this.db.exec(
      "PRAGMA journal_mode=WAL; PRAGMA busy_timeout=5000; CREATE TABLE IF NOT EXISTS runs(id TEXT PRIMARY KEY, created TEXT NOT NULL, payload TEXT NOT NULL); CREATE TABLE IF NOT EXISTS suites(id TEXT PRIMARY KEY, payload TEXT NOT NULL);",
    );
  }
  runs() {
    return this.db
      .prepare("SELECT payload FROM runs ORDER BY created DESC")
      .all()
      .map((r) => JSON.parse(r.payload));
  }
  get(id) {
    const row = this.db.prepare("SELECT payload FROM runs WHERE id=?").get(id);
    return row ? JSON.parse(row.payload) : null;
  }
  put(run) {
    this.db
      .prepare(
        "INSERT INTO runs VALUES(?,?,?) ON CONFLICT(id) DO UPDATE SET payload=excluded.payload",
      )
      .run(run.id, run.createdAt, JSON.stringify(run));
  }
  suites() {
    return this.db
      .prepare("SELECT payload FROM suites")
      .all()
      .map((r) => JSON.parse(r.payload));
  }
  saveSuite(suite) {
    this.db
      .prepare(
        "INSERT INTO suites VALUES(?,?) ON CONFLICT(id) DO UPDATE SET payload=excluded.payload",
      )
      .run(suite.id, JSON.stringify(suite));
  }
  deleteSuite(id) {
    this.db.prepare("DELETE FROM suites WHERE id=?").run(id);
  }
  close() {
    this.db.close();
  }
}
