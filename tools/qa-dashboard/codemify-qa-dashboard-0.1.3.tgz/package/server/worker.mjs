import { spawn, execFile } from "node:child_process";

// The IPC pipe closes if the dashboard crashes. Reap only this worker's own tree.
const child = spawn(process.execPath, process.argv.slice(2), {
  env: process.env,
  cwd: process.cwd(),
  windowsHide: true,
  shell: false,
  detached: process.platform !== "win32",
  stdio: "inherit",
});
let stopping = false;
function stop() {
  if (stopping || !child.pid) return;
  stopping = true;
  if (process.platform === "win32")
    execFile(
      "taskkill",
      ["/pid", String(child.pid), "/t", "/f"],
      { windowsHide: true },
      () => process.exit(130),
    );
  else {
    try {
      process.kill(-child.pid, "SIGTERM");
    } catch {
      child.kill("SIGTERM");
    }
    setTimeout(() => {
      try {
        process.kill(-child.pid, "SIGKILL");
      } catch {
        child.kill("SIGKILL");
      }
      process.exit(130);
    }, 5000).unref();
  }
}
process.on("disconnect", stop);
process.on("message", (message) => {
  if (message?.type === "stop") stop();
});
process.on("SIGTERM", stop);
process.on("SIGINT", stop);
child.on("error", (error) => {
  console.error(error.message);
  process.exit(1);
});
child.on("close", (code) => process.exit(code ?? 1));
